# core/trading.py
from utils.logger import logger

def start_trading_loop():
    logger.info("Trading loop would run here.")
