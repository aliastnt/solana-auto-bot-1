# main.py
from bot.telegram_bot import start_telegram_bot
from core.trading import start_trading_loop
from utils.logger import logger

if __name__ == "__main__":
    logger.info("Starting Solana Meme Trading Bot...")
    start_trading_loop()
    start_telegram_bot()
