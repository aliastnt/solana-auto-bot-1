# bot/telegram_bot.py
from telegram.ext import Updater, CommandHandler
from utils.config import TELEGRAM_BOT_TOKEN, CHAT_ID
from utils.logger import logger

def start(update, context):
    update.message.reply_text("Bot is running!")

def start_telegram_bot():
    updater = Updater(token=TELEGRAM_BOT_TOKEN, use_context=True)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))
    updater.start_polling()
    logger.info("Telegram bot started.")
